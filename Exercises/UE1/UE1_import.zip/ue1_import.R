# basic commands


# example dataset


# variables


###############################################

# install libraries


# import libraries


###############################################

# csv files


# for excel data


# other formats



# For further reference:
# https://r4ds.had.co.nz/data-import.html#:~:text=read_csv()%20reads%20comma%20delimited,in%20files%20with%20any%20delimiter.


###############################################

# check the imported dataframes


# have a glimpse at the data




###############################################

## What would be the next step?

